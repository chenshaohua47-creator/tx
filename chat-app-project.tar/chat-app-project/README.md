# 🔐 私密聊天应用 | Secret Chat App

一个**完全伪装成计算器**的两人私密聊天网页应用。外人看起来只是一个普通的计算器，实际上是一个功能完整的实时聊天应用。

## ✨ 特色

- 🔒 **计算器伪装** - 完全看不出是聊天应用
- ⏰ **时间密码锁** - 密码每分钟自动变化，无法破解
- 💬 **实时聊天** - 3秒轮询，双向消息同步
- 📸 **图片发送** - 支持相机拍照上传
- 😊 **表情包** - 22个常用表情快速插入
- 🔄 **消息撤回** - 2分钟内双击撤回
- 🌙 **深色模式** - 自动适配系统主题
- 📱 **响应式设计** - 完美支持手机和平板
- 🚀 **零依赖** - 纯 HTML/CSS/JS，无外部库

## 🎯 使用流程

1. **打开链接** → 看到计算器界面
2. **点任意按钮** → 继续用计算器掩饰
3. **按"="按钮** → 弹出密码输入框
4. **输入时间密码** → 例如现在21:30，输入 `2130`
5. **进入聊天** → 开始私密对话 🎉

## 🛠️ 快速开始

### 方案1: 使用腾讯云 CloudBase（推荐）

#### 1️⃣ 创建 CloudBase 环境
```bash
# 安装 CloudBase CLI
npm install -g @cloudbase/cli

# 初始化项目
cloudbase init

# 登录
cloudbase login
```

#### 2️⃣ 部署后端（云函数）
```bash
# 进入项目目录
cd chat-app-project

# 复制云函数代码到 functions/chat/index.js
mkdir -p functions/chat
cp backend/cloud-function.js functions/chat/index.js

# 部署云函数
cloudbase functions:deploy chat -l nodejs18

# 配置 HTTP 触发
# 在 CloudBase 控制台 → 云函数 → chat → HTTP 访问服务 → 启用
```

#### 3️⃣ 部署前端
```bash
# 修改前端 API 地址
# 编辑 frontend/index.html，找到这行：
# const API = "https://YOUR_ENV_ID-YOUR_REGION.app.tcloudbase.com/chat";

# 上传到静态托管
cloudbase hosting:deploy frontend -e YOUR_ENV_ID
```

### 方案2: 使用其他云厂商（阿里云、AWS等）

1. **部署后端**：使用任何支持 Node.js 的云函数平台
2. **修改 API 地址**：编辑 `frontend/index.html` 中的 `const API = "..."`
3. **部署前端**：上传到任何静态托管（OSS、COS、S3等）

### 方案3: 自建服务器

```bash
# 1. 在服务器上部署后端
# 使用 backend/simple-server.js 作为参考

# 2. 修改前端 API 地址
# const API = "https://your-domain.com/chat";

# 3. 用 Nginx 托管前端
# 将 frontend/index.html 复制到 web 目录
```

## 📁 项目结构

```
chat-app-project/
├── frontend/
│   └── index.html          # 前端代码（计算器 + 聊天UI）
├── backend/
│   ├── cloud-function.js   # 腾讯云函数代码
│   └── simple-server.js    # 自建服务器参考代码
├── docs/
│   ├── DEPLOYMENT.md       # 详细部署指南
│   ├── API.md              # API 文档
│   └── MIGRATION.md        # 迁移指南
├── README.md               # 本文件
└── .env.example            # 环境变量示例
```

## 🔑 环境变量配置

1. 复制 `.env.example` 为 `.env`
2. 填入你的配置：

```env
# CloudBase 环境 ID
CLOUDBASE_ENV_ID=your-env-id

# 域名配置
API_URL=https://your-env-id.app.tcloudbase.com/chat

# 账号配置
ACCOUNT_A_NAME=账号 A
ACCOUNT_B_NAME=账号 B
ACCOUNT_A_AVATAR=https://i.pravatar.cc/100?img=53
ACCOUNT_B_AVATAR=https://i.pravatar.cc/100?img=12
```

## 🚀 一键部署脚本

### 腾讯云部署脚本

```bash
#!/bin/bash
# deploy.sh

# 设置环境变量
export CLOUDBASE_ENV_ID="your-env-id"
export REGION="ap-shanghai"

# 登录
cloudbase login

# 部署后端
echo "部署云函数..."
mkdir -p functions/chat
cp backend/cloud-function.js functions/chat/index.js
cloudbase functions:deploy chat -l nodejs18 -e $CLOUDBASE_ENV_ID

# 部署前端
echo "部署前端..."
cloudbase hosting:deploy frontend -e $CLOUDBASE_ENV_ID

echo "✅ 部署完成！"
echo "访问地址: https://$CLOUDBASE_ENV_ID-1257314594.tcloudbaseapp.com/index.html"
```

保存为 `deploy.sh`，运行：
```bash
chmod +x deploy.sh
./deploy.sh
```

## 📝 API 文档

### 发送消息
```javascript
fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
        action: "send",
        sender: "A",  // 或 "B"
        text: "你好",
        createdAt: Date.now()
    })
})
```

### 获取消息
```javascript
fetch(API, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action: "get" })
})
// 返回: { ok: true, messages: [...] }
```

## 🔐 安全建议

1. **更换默认账号** - 修改 `CONFIG` 中的账号名和头像
2. **更换时间密码** - 根据实际需要调整密码生成逻辑
3. **启用 HTTPS** - 确保所有通信加密
4. **限制 API 访问** - 配置跨域和频率限制
5. **定期备份** - 定期备份数据库数据

## 🐛 常见问题

**Q: 换服务器后无法连接？**
A: 检查 `frontend/index.html` 中的 `const API` 是否指向新的后端地址。

**Q: 消息没有同步？**
A: 确保后端云函数已正确部署，检查 CloudBase 日志。

**Q: 图片上传失败？**
A: Base64 编码可能超过 1MB 限制，选择较小的图片。

**Q: 需要修改密码格式？**
A: 编辑 `checkPwd()` 函数中的时间密码生成逻辑。

## 📚 更多文档

- [详细部署指南](docs/DEPLOYMENT.md)
- [API 文档](docs/API.md)
- [迁移指南](docs/MIGRATION.md)

## 📜 许可证

MIT License - 可自由使用和修改

## 🤝 贡献

欢迎 Fork 和 Pull Request！

## ⚠️ 免责声明

本项目仅供学习和私人使用，请遵守当地法律法规。不建议用于任何非法目的。

---

**需要帮助？** 查看 [docs/](docs/) 文件夹获取详细指南。

**最后更新**: 2026-05-04
