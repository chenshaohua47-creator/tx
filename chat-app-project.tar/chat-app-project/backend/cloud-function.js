/**
 * 腾讯云 CloudBase 云函数 - 聊天后端
 * 
 * 部署步骤:
 * 1. 在 CloudBase 控制台创建云函数 "chat"
 * 2. 复制本代码到函数编辑器
 * 3. 启用 HTTP 触发
 * 4. 完成部署
 */

const cloud = require('@cloudbase/node-sdk')
const app = cloud.init({ env: cloud.SYMBOL_CURRENT_ENV })
const db = app.database()

/**
 * 主处理函数
 */
exports.main = async (event) => {
  // 解析请求体
  let body = event
  if (event.body) {
    try {
      body = JSON.parse(event.body)
    } catch(e) {
      body = event
    }
  }
  
  const action = body.action
  
  // 发送消息
  if (action === 'send') {
    try {
      await db.collection('messages').add({
        sender: body.sender,
        text: body.text,
        createdAt: body.createdAt || Date.now()
      })
      return { ok: true }
    } catch(e) {
      console.error('发送消息失败:', e)
      return { ok: false, error: e.message }
    }
  }
  
  // 获取消息
  if (action === 'get') {
    try {
      const res = await db.collection('messages')
        .orderBy('createdAt', 'asc')
        .limit(100)
        .get()
      return { ok: true, messages: res.data }
    } catch(e) {
      console.error('获取消息失败:', e)
      return { ok: false, error: e.message }
    }
  }
  
  return { ok: false, action: action, body: body }
}

/**
 * 备注说明:
 * 
 * 1. 数据库集合要求:
 *    - 集合名: messages
 *    - 索引: createdAt (用于排序)
 *    - 权限: 允许登录用户读写
 * 
 * 2. 消息格式:
 *    {
 *      "_id": "auto",
 *      "sender": "A" or "B",
 *      "text": "消息内容或特殊命令",
 *      "createdAt": 时间戳
 *    }
 * 
 * 3. 特殊命令:
 *    - "[CMD_RECALL_时间戳]" - 撤回消息
 *    - "[IMG]base64数据" - 图片消息
 * 
 * 4. 安全建议:
 *    - 启用身份认证（匿名登录）
 *    - 设置数据库权限为"登录用户可读写"
 *    - 定期清理旧消息（>2天的消息）
 *    - 限制消息大小和发送频率
 */
