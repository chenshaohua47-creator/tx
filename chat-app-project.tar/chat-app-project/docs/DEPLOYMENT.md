# 📦 完整部署指南

## 方案选择

选择最适合你的部署方案：

| 方案 | 难度 | 成本 | 特点 |
|-----|------|------|------|
| **腾讯云 CloudBase** | ⭐ 简单 | 免费到付费 | 官方集成，快速部署 |
| **其他云厂商** | ⭐⭐ 中等 | 按需付费 | 灵活选择，成本透明 |
| **自建服务器** | ⭐⭐⭐ 复杂 | 需购买服务器 | 完全控制，需维护 |

---

## 方案 1️⃣: 腾讯云 CloudBase（推荐）

### 步骤 1: 准备工作

1. 访问 [腾讯云 CloudBase 控制台](https://console.cloud.tencent.com/tcb)
2. 注册账号（新用户有免费额度）
3. 创建环境（选择 "按量计费" 或 "标准版"）
4. 记住 **环境 ID** 和 **地域**

### 步骤 2: 创建数据库集合

1. 进入 CloudBase 控制台
2. 选择你的环境 → **数据库**
3. 创建集合 `messages`
4. 添加索引：
   - 索引名: `createdAt`
   - 字段: `createdAt`
   - 排序: 升序

5. 设置权限为 **"登录用户可读写"**

### 步骤 3: 创建云函数

1. 进入 **云函数** → **新建云函数**
2. 函数名: `chat`
3. 运行环境: `Node.js 18`
4. 复制 `backend/cloud-function.js` 的代码到编辑器
5. 安装依赖: 在 `package.json` 中添加
   ```json
   {
     "dependencies": {
       "@cloudbase/node-sdk": "latest"
     }
   }
   ```
6. **保存并部署**

### 步骤 4: 启用 HTTP 触发

1. 进入 `chat` 函数详情
2. 找到 **"HTTP 访问服务"**
3. 启用 HTTP 触发
4. 选择路由: `/chat`
5. 记住生成的 **访问 URL**

### 步骤 5: 修改前端代码

编辑 `frontend/index.html`，找到这行：

```javascript
const API = "https://jjyyds-d0gjwppe2e596982d-1257314594.ap-shanghai.app.tcloudbase.com/chat";
```

替换为你的 URL：

```javascript
const API = "https://YOUR_ENV_ID-UNIQUE_ID.ap-REGION.app.tcloudbase.com/chat";
```

### 步骤 6: 部署前端

#### 方式 A: 用 CloudBase CLI

```bash
# 安装 CLI
npm install -g @cloudbase/cli

# 登录
cloudbase login

# 部署
cloudbase hosting:deploy frontend -e YOUR_ENV_ID

# 访问地址会自动显示
```

#### 方式 B: 手动上传

1. 进入 **静态托管**
2. 点 **"上传文件"**
3. 选择 `frontend/index.html`
4. 完成上传
5. 复制公网访问链接

### ✅ 完成！

访问生成的链接，开始使用！

---

## 方案 2️⃣: 阿里云 OSS + 函数计算

### 后端部署

1. 创建阿里云函数计算
2. 创建 Node.js 函数
3. 复制 `backend/cloud-function.js` 代码（需改成阿里云 SDK）
4. 配置 HTTP 触发

### 前端部署

1. 创建 OSS Bucket
2. 上传 `frontend/index.html`
3. 修改前端中的 API 地址

### 参考文档
- [函数计算文档](https://help.aliyun.com/product/50127.html)
- [OSS 文档](https://help.aliyun.com/product/31815.html)

---

## 方案 3️⃣: AWS Lambda + S3

### 后端部署

1. 创建 Lambda 函数（Node.js 18）
2. 复制后端代码，改成 AWS SDK
3. 连接 DynamoDB 数据库
4. 配置 API Gateway

### 前端部署

1. 上传到 S3 Static Hosting
2. 使用 CloudFront CDN（可选）

### 参考文档
- [Lambda 文档](https://docs.aws.amazon.com/lambda/)
- [S3 文档](https://docs.aws.amazon.com/s3/)

---

## 方案 4️⃣: 自建服务器

### 需要的东西

- VPS（推荐 Nginx + Node.js）
- 域名（可选，用 IP 也行）
- SSL 证书（推荐）

### 部署步骤

1. **连接服务器**
   ```bash
   ssh root@your_server_ip
   ```

2. **安装 Node.js**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **创建项目目录**
   ```bash
   mkdir -p /var/www/chat-app
   cd /var/www/chat-app
   ```

4. **上传文件**
   ```bash
   scp -r backend/ root@your_server_ip:/var/www/chat-app/
   scp -r frontend/ root@your_server_ip:/var/www/chat-app/
   ```

5. **配置数据库**
   - 使用 MongoDB、PostgreSQL 或 MySQL
   - 创建 messages 表

6. **启动后端**
   ```bash
   cd backend
   npm install
   node server.js
   ```

7. **配置 Nginx**
   ```nginx
   server {
       listen 80;
       server_name your_domain.com;

       # 前端
       location / {
           root /var/www/chat-app/frontend;
           try_files $uri /index.html;
       }

       # 后端 API
       location /api/chat {
           proxy_pass http://127.0.0.1:3000/chat;
       }
   }
   ```

8. **启用 HTTPS**
   ```bash
   sudo apt-get install certbot python3-certbot-nginx
   sudo certbot --nginx -d your_domain.com
   ```

---

## 迁移步骤

从一个服务器迁移到另一个：

### 备份数据

```bash
# 导出 CloudBase 数据
cloudbase database:export messages -e YOUR_ENV_ID -o messages-backup.json
```

### 恢复到新服务器

```bash
# 导入到新环境
cloudbase database:import messages -e NEW_ENV_ID -f messages-backup.json
```

### 更新前端链接

修改 `frontend/index.html` 中的 API 地址即可。

---

## 常见问题排查

### Q: 部署后显示 "连接失败"

**检查清单：**
1. ✅ 云函数是否成功部署？
2. ✅ HTTP 触发是否启用？
3. ✅ 前端中的 API 地址是否正确？
4. ✅ 数据库集合是否创建？
5. ✅ 权限是否设置为 "登录用户可读写"？

### Q: 消息无法同步

1. 检查浏览器控制台的错误信息
2. 查看 CloudBase 日志
3. 确认数据库没有存储配额限制

### Q: 图片上传失败

1. 检查图片大小（<1MB）
2. 检查数据库存储空间

### Q: 密码不对

1. 检查手机时间是否准确
2. 确认密码格式是 HHMM（如 2130）

---

## 安全建议

### ✅ 必做

- [ ] 启用 HTTPS
- [ ] 设置数据库权限
- [ ] 启用身份认证
- [ ] 定期备份数据

### 🔐 可选加强

- [ ] 配置 CDN
- [ ] 启用 DDoS 防护
- [ ] 限制 API 频率
- [ ] 加密敏感数据

---

## 成本估算

### 腾讯云 CloudBase
- 免费配额：存储 5GB，调用 100 万次/月
- 超出后：约 ¥0.0000014/次

### 自建服务器
- VPS 成本：¥50-200/月
- 域名：¥50-100/年
- SSL 证书：免费（Let's Encrypt）

---

**需要帮助？** 在 GitHub 提交 Issue！
